#include "iostream"
#include "algorithm"
#include "climits"

// const int MAXN = 1e3;
// int map[MAXN][MAXN] = {0};
int N;

int main() {
    // std::cin >>N;
    N = 4;
    int arr[N][N] = {
        {1, 2, 3, 4},
        {2, 4, 1, 6},
        {2, 6, 3, 8},
        {2, 8, 3, 2}
    };

    for(int i=0; i<N; ++i)
    {
        int min_1 = INT_MAX, index_j1 = 0, index_i1 = 0;
        for(int j=0; j<N; ++j)  //行找
        {
            if(arr[i][j] < min_1){
                min_1 = arr[i][j];
                index_j1 = j;
                index_i1 = i;
            }
        }
        int min_2 = INT_MAX, index_j2 = 0, index_i2 = 0;
        for(int j=index_j1; j<N; ++j){ //列找

        }
    }

    return 0;
}
